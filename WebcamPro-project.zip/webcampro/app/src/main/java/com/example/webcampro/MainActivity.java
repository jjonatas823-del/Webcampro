package com.example.webcampro;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private PreviewView previewView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this); title.setText("Webcam Pro\nCamera preview — prototype"); title.setTextSize(20); title.setPadding(20,24,20,24);
        previewView = new PreviewView(this); previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        layout.addView(title); layout.addView(previewView, new LinearLayout.LayoutParams(-1,0,1)); setContentView(layout);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera();
        else ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},10);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results); if(requestCode==10 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) startCamera();}
    private void startCamera(){
        ProcessCameraProvider.getInstance(this).addListener(() -> { try {
            ProcessCameraProvider provider=ProcessCameraProvider.getInstance(this).get(); provider.unbindAll();
            Preview preview=new Preview.Builder().build(); preview.setSurfaceProvider(previewView.getSurfaceProvider());
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview);
        } catch(Exception e) { } }, ContextCompat.getMainExecutor(this));
    }
}
