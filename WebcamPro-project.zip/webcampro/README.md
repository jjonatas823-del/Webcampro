# Webcam Pro (prototype)
Independent Android camera-preview prototype. This is not a modification of Iriun and does not yet stream video to a desktop receiver.

Build APK: push to GitHub, then Actions > Build APK > run workflow. Download the APK artifact after the build finishes.
